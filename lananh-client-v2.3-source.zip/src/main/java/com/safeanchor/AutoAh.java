package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Tự mở /ah, tìm món theo từ khóa có giá <= mức tối đa rồi bấm mua + xác nhận. (GUI mỗi server khác nhau, cần thử trên KingMC) */
public class AutoAh {
    static int cd, wait;
    static final Pattern NUM = Pattern.compile("(\\d[\\d.,]*)\\s*([kKmMbB]?)");
    static final Set<net.minecraft.item.Item> CONFIRM = Set.of(Items.LIME_STAINED_GLASS_PANE, Items.GREEN_STAINED_GLASS_PANE,
            Items.LIME_TERRACOTTA, Items.GREEN_TERRACOTTA, Items.EMERALD_BLOCK, Items.LIME_CONCRETE, Items.GREEN_CONCRETE, Items.LIME_WOOL, Items.GREEN_WOOL);

    public static void toggle(MinecraftClient mc) {
        Config.I.ahOn = !Config.I.ahOn; Config.save();
        Util.msg("Auto /ah: " + (Config.I.ahOn ? "§aBẬT" : "§cTẮT"));
    }

    static double price(ItemStack s) {
        var lore = s.get(DataComponentTypes.LORE);
        if (lore == null) return -1;
        for (Text line : lore.lines()) {
            String t = line.getString();
            String l = t.toLowerCase();
            if (!(l.contains("$") || l.contains("price") || l.contains("giá") || l.contains("gia"))) continue;
            Matcher m = NUM.matcher(t.replace(",", ""));
            if (m.find()) {
                try {
                    double v = Double.parseDouble(m.group(1));
                    String u = m.group(2).toLowerCase();
                    return u.equals("k") ? v * 1e3 : u.equals("m") ? v * 1e6 : u.equals("b") ? v * 1e9 : v;
                } catch (Exception ignored) {}
            }
        }
        return -1;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.ahOn || p == null || mc.interactionManager == null) return;
        if (cd > 0) { cd--; return; }
        if (!(mc.currentScreen instanceof GenericContainerScreen gs)) {
            if (mc.currentScreen == null && !c.ahKeyword.isBlank()) { p.networkHandler.sendChatCommand("ah"); cd = Math.max(20, c.ahInterval); wait = 10; }
            return;
        }
        if (wait > 0) { wait--; return; }
        GenericContainerScreenHandler h = gs.getScreenHandler();
        int n = h.getRows() * 9;
        // màn xác nhận?
        for (int i = 0; i < n; i++) {
            ItemStack s = h.getSlot(i).getStack();
            if (CONFIRM.contains(s.getItem()) && gs.getTitle().getString().toLowerCase().matches(".*(confirm|xác nhận|xac nhan|purchase|mua).*")) {
                mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.PICKUP, p); cd = 15; return;
            }
        }
        String kw = c.ahKeyword.toLowerCase();
        int best = -1; double bp = Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            ItemStack s = h.getSlot(i).getStack();
            if (s.isEmpty() || !s.getName().getString().toLowerCase().contains(kw)) continue;
            double pr = price(s);
            if (pr <= 0 || (c.ahMaxPrice > 0 && pr > c.ahMaxPrice)) continue;
            if (pr < bp) { bp = pr; best = i; }
        }
        if (best >= 0) { mc.interactionManager.clickSlot(h.syncId, best, 0, SlotActionType.PICKUP, p); cd = 10; wait = 5; }
        else { p.closeHandledScreen(); cd = Math.max(20, c.ahInterval); }
    }
}
