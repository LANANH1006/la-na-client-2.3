package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Các trang cài đặt cho tính năng mới (v2.3). */
public class Pages2 {
    static Config C() { return Config.I; }
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    static Screen pvp(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Auto PvP (phím V)", () -> C().autoPvp, v -> { if (v != C().autoPvp) AutoPvp.toggle(mc()); }));
        m.add(Pages.toggle("Tự bật Auto Crystal/Anchor khi PvP", () -> C().pvpCrystal, v -> C().pvpCrystal = v));
        m.add(Pages.toggle("Tự chạy tới đối thủ", () -> C().pvpWalk, v -> C().pvpWalk = v));
        m.add(Pages.toggle("Tự đổi totem", () -> C().autoTotem, v -> C().autoTotem = v));
        m.add(Pages.slider("Tầm đánh", 2.5, 6, false, () -> C().pvpRange, v -> C().pvpRange = v));
        m.add(Pages.slider("Độ mượt xoay (thấp = mượt)", 10, 100, true, () -> C().pvpSmooth * 100, v -> C().pvpSmooth = v / 100.0));
        m.add(Pages.toggle("Auto Crystal", () -> C().crystal, v -> C().crystal = v));
        m.add(Pages.toggle("Safe Anchor", () -> C().anchor, v -> C().anchor = v));
        return new MenuScreen("Auto PvP", p, m);
    }

    static Screen mine(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Tự đào (phím N)", () -> C().mineOn, v -> { if (v != C().mineOn) AutoMine.toggle(mc()); }));
        m.add(Pages.slider("Tầm tìm block (block)", 6, 24, true, () -> C().mineRange, v -> C().mineRange = v));
        TextFieldWidget[] tf = new TextFieldWidget[1];
        m.add(() -> { tf[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("id")); tf[0].setPlaceholder(Text.literal("vd: iron_ore")); tf[0].setMaxLength(64); return tf[0]; });
        m.add(Pages.button("➕ Thêm block cần đào", () -> {
            String s = tf[0].getText().trim().toLowerCase();
            if (!s.isEmpty() && !C().mineList.contains(s)) { C().mineList.add(s); Config.save(); }
            mc().setScreen(mine(p));
        }));
        for (String id : new ArrayList<>(C().mineList))
            m.add(Pages.button("❌ Bỏ: " + id, () -> { C().mineList.remove(id); Config.save(); mc().setScreen(mine(p)); }));
        return new MenuScreen("Tự đào", p, m);
    }

    static Screen ah(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Auto /ah mua", () -> C().ahOn, v -> C().ahOn = v));
        TextFieldWidget[] kw = new TextFieldWidget[1], pr = new TextFieldWidget[1];
        m.add(() -> { kw[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("kw")); kw[0].setPlaceholder(Text.literal("Tên món (vd: diamond)")); kw[0].setText(C().ahKeyword); return kw[0]; });
        m.add(() -> { pr[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("pr")); pr[0].setPlaceholder(Text.literal("Giá tối đa (0 = không giới hạn)")); pr[0].setText(C().ahMaxPrice == 0 ? "" : String.valueOf((long) C().ahMaxPrice)); return pr[0]; });
        m.add(Pages.button("💾 Lưu từ khóa + giá", () -> {
            C().ahKeyword = kw[0].getText().trim();
            try { C().ahMaxPrice = pr[0].getText().isBlank() ? 0 : Double.parseDouble(pr[0].getText().trim()); } catch (Exception e) { C().ahMaxPrice = 0; }
            Config.save(); Util.msg("Đã lưu /ah");
        }));
        m.add(Pages.slider("Chu kỳ mở /ah (tick)", 20, 400, true, () -> C().ahInterval, v -> C().ahInterval = (int) v));
        return new MenuScreen("Auto /ah", p, m);
    }

    static Screen sus(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Hiện chunk đáng nghi (đỏ)", () -> C().susOn, v -> C().susOn = v));
        m.add(Pages.slider("Số block người đặt tối thiểu / chunk", 10, 300, true, () -> C().susMin, v -> C().susMin = (int) v));
        m.add(Pages.slider("Sâu dưới mặt đất (block)", 1, 20, true, () -> C().susDepth, v -> C().susDepth = (int) v));
        m.add(Pages.slider("Độ đậm khối đặc (ESP)", 10, 200, true, () -> C().espAlpha, v -> C().espAlpha = (int) v));
        return new MenuScreen("Sus chunk", p, m);
    }

    static Screen chat(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Dịch chat Anh -> Việt (hiện thêm dòng)", () -> C().chatIn, v -> C().chatIn = v));
        m.add(Pages.toggle("Tin gõ tiếng Việt (có dấu) -> gửi tiếng Anh", () -> C().chatOut, v -> C().chatOut = v));
        return new MenuScreen("Dịch chat", p, m);
    }
}
